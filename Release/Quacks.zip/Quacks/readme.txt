QuackBarkA will bark always
QuackBarkS will bark not always